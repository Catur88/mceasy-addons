from odoo import models, fields, api, _


class reportmodel(models.Model):
    name = fields.Char()
